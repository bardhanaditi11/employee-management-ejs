const express = require('express');
const router = express.Router();
const controller = require('../controller/performance.controller');

router.get('/', controller.index);
router.get('/add', controller.addForm);
router.post('/', controller.create);

module.exports = router;
