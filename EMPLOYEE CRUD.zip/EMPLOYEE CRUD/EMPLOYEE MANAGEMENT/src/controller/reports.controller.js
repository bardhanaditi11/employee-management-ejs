const records = [];

exports.index = (req, res) => {
  res.render('reports', { title: 'Reports', records });
};

exports.addForm = (req, res) => {
  res.render('reports_add', { title: 'Add Report' });
};

exports.create = (req, res) => {
  records.push({ ...req.body, id: Date.now() });
  res.redirect('/reports');
};
