const records = [];

exports.index = (req, res) => {
  res.render('departments', { title: 'Departments', records });
};

exports.addForm = (req, res) => {
  res.render('departments_add', { title: 'Add Department' });
};

exports.create = (req, res) => {
  records.push({ ...req.body, id: Date.now() });
  res.redirect('/departments');
};
