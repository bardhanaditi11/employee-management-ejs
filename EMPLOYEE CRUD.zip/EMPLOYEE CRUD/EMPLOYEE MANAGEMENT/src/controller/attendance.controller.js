const records = [];

exports.index = (req, res) => {
  res.render('attendance', { title: 'Attendance', records });
};

exports.addForm = (req, res) => {
  res.render('attendance_add', { title: 'Add Attendance' });
};

exports.create = (req, res) => {
  records.push({ ...req.body, id: Date.now() });
  res.redirect('/attendance');
};
