const records = [];

exports.index = (req, res) => {
  res.render('payroll', { title: 'Payroll', records });
};

exports.addForm = (req, res) => {
  res.render('payroll_add', { title: 'Add Payroll' });
};

exports.create = (req, res) => {
  records.push({ ...req.body, id: Date.now() });
  res.redirect('/payroll');
};
