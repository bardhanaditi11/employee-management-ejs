const records = [];

exports.index = (req, res) => {
  res.render('leave', { title: 'Leave', records });
};

exports.addForm = (req, res) => {
  res.render('leave_add', { title: 'Add Leave' });
};

exports.create = (req, res) => {
  records.push({ ...req.body, id: Date.now() });
  res.redirect('/leave');
};
