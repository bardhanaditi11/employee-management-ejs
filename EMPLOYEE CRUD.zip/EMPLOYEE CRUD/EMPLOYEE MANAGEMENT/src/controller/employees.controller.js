const records = [];

exports.index = (req, res) => {
  res.render('employees', { title: 'Employees', records });
};

exports.addForm = (req, res) => {
  res.render('employees_add', { title: 'Add Employee' });
};

exports.create = (req, res) => {
  records.push({ ...req.body, id: Date.now() });
  res.redirect('/employees');
};
