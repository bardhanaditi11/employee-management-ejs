const records = [];

exports.index = (req, res) => {
  res.render('performance', { title: 'Performance', records });
};

exports.addForm = (req, res) => {
  res.render('performance_add', { title: 'Add Performance' });
};

exports.create = (req, res) => {
  records.push({ ...req.body, id: Date.now() });
  res.redirect('/performance');
};
