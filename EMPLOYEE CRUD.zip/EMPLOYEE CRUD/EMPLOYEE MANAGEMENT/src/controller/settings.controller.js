const records = [];

exports.index = (req, res) => {
  res.render('settings', { title: 'Settings', records });
};

exports.addForm = (req, res) => {
  res.render('settings_add', { title: 'Add Setting' });
};

exports.create = (req, res) => {
  records.push({ ...req.body, id: Date.now() });
  res.redirect('/settings');
};
