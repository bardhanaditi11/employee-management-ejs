const express = require('express');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 6001;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

app.get('/', (req, res) => {
  res.render('home', { title: 'Employee Management Dashboard' });
});

app.use('/employees', require('./router/employees.route'));
app.use('/departments', require('./router/departments.route'));
app.use('/attendance', require('./router/attendance.route'));
app.use('/leave', require('./router/leave.route'));
app.use('/payroll', require('./router/payroll.route'));
app.use('/performance', require('./router/performance.route'));
app.use('/reports', require('./router/reports.route'));
app.use('/settings', require('./router/settings.route'));

app.use((req, res) => res.status(404).send('404 - Page not found'));

app.listen(PORT, () => {
  console.log(`Employee Management running at http://localhost:${PORT}`);
});
